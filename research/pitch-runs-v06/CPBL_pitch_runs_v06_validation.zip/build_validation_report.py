from pathlib import Path
import json,sys,gzip,hashlib
import pandas as pd,numpy as np,joblib
from validate_pitch_runs import CLASSES,BRANCH,count_branches,absorb
root=Path('results/v06');m=json.loads((root/'metrics.json').read_text());profiles=json.loads((root/'profiles.json').read_text());values=json.loads((root/'value-tables.json').read_text())
raw=pd.read_csv('data/CPBL_2026_predict_data/data/pitch_training_rows.csv.gz');row=raw[raw.pitch_id.eq('cpbl:2026-A-286:log:282')].iloc[0]
base=joblib.load(root/'baseline.joblib');pitch=joblib.load(root/'pitch.joblib');x={k:(None if pd.isna(row.get(k)) else float(row[k])) for k in pitch['features'] if k in raw.columns}
bh=profiles['batters'].get(str(int(row.batter_id)),profiles['batter_prior']);ph=profiles['pitchers'].get(str(int(row.pitcher_id)),profiles['pitcher_prior'])
for k,v in zip(['history_exit','history_angle','history_direction','history_n'],bh):x[k]=v
for k,v in zip(CLASSES,ph):x['pitcher_rate_'+k]=v
bx=pd.DataFrame([{**x,'balls_before':b,'strikes_before':s} for b in range(4) for s in range(3)]);future=count_branches(base['model'].predict_proba(bx[base['features']].to_numpy(float)).reshape(4,3,10));v=np.array(values['values'][int(row.pa_outs_before_audited*8+row.pa_bases_before_audited)]);e0=float(future[0,0]@v)
examples=[]
for px in [0.,float(row.plate_x_m)]:
 xx={**x,'plate_x_m':px};q=pitch['model'].predict_proba(pd.DataFrame([xx])[pitch['features']].to_numpy(float))[0];after=absorb(q,future,0,0);e1=float(after@v);examples.append({'x_m':px,'z_m':float(row.plate_z_m),'velocity_kph':float(row.velocity_kph),'E0':e0,'E1':e1,'pitcher_runs':e0-e1})
m['single_condition_demo']={'source_pitch':row.pitch_id,'batter':row.batter_name,'pitcher':row.pitcher_name,'outs':int(row.pa_outs_before_audited),'bases':int(row.pa_bases_before_audited),'count':'0-0','only_changed':'plate_x_m','rows':examples,'status':'conditional model simulations; source case chosen to illustrate a large shift, not representative or causal evidence'}
(root/'metrics.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf8')
rs=m['run_value_test'];p0=m['test']['baseline'];p1=m['test']['pitch'];rm=rs['metrics'];a,b=examples
text=f'''# CPBL 投球資訊到預期得分：v0.6 驗證

核對日期：2026-11-21。這次是環境中斷後，以相同資料重新擬合的研究模型（Python {m['python']}、scikit-learn {m['sklearn']}），並非取回原Windows權重後逐位元重現。

## 結論

已完成機率到runs的計算與驗證，可以輸出投手資訊階段貢獻 E0−E1。
逐球機率有改善，換成剩餘得分後改善很小，尚無足夠證據穩定優於RE24。未完成完整個人責任驗證，沒有修改正式首頁。

## 計算

先分成BALL、STRIKE、FOUL、HBP、CONTACT_OUT、1B、2B、3B、HR、OTHER十類逐球反應。
基準模型只使用壘況、出局數、球數與凍結投打歷史；投球模型再加入x/z、球速、轉速、出手高度／側向與延伸。
沒有將實際初速、仰角、落點或打席終結標籤放進投球特徵。

對4種壞球數×3種好球數，倒推整個打席最終八類結果機率：

- 第四壞球進WALK；第三好球進K。
- 兩好球前界外球增加一好球；兩好球後界外球留在原球數。
- 場內結果與觸身球進入相應終結分支。
- 未知未來球路用基準模型的球數／情境機率，並非假設每顆未來球都投在現在位置。

E0 = Σ P(最終結果 | 本球前情境) × V結果。
E1 = Σ P(最終結果 | 本球投球資訊、其餘球路未知) × V結果。
投手貢獻（防守正向）= E0−E1。

此驗證的V使用訓練期事件平均直接得分加事件後聯盟RE；稀疏state/branch回退同分支全訓練平均。未含網站的下一棒擴充，不能將此成績命名為完整網站模型成效。

## 資料與切分

| 區段 | 日期 | 投球數 | 場數 |
| --- | --- | ---: | ---: |
| 訓練 | 3/28–6/30 | {m['splits']['train']['n']:,} | 144 |
| 驗證 | 政策7/1–8/22，實際至8/18 | {m['splits']['validation']['n']:,} | 63 |
| 開發測試 | 8/23–10/6 | {m['splits']['test']['n']:,} | 88 |

採資料包strict_pitch_training_eligible，另限RE可用、來源當前壘況／出局數與打席開始審核狀態一致、可映射的逐球標籤。保留唯一pitch_id，三區比賽ID互不重疊。
打者擊球歷史以30偽樣本收縮，投手逐球反應率以100偽樣本收縮；訓練逐日前綴，驗證與測試凍結6月底歷史。聯盟先驗只由訓練區塊估計。
後段曾被專案分析；這是重複使用的開發測試，不是全新保留測試。PreExeDate是來源排程日期，續賽實際時序尚未核對。

## 逐球機率（同23,906球）

| 指標（越低越好） | 情境／歷史基準 | 加入本球資訊 |
| --- | ---: | ---: |
| 多類Log Loss | {p0['log_loss']:.6f} | {p1['log_loss']:.6f} |
| 多類Brier（類別平方差加總） | {p0['multiclass_brier_sum']:.6f} | {p1['multiclass_brier_sum']:.6f} |

Log Loss差（投球模型−基準）的整場bootstrap 95%區間：{m['pitch_probability_difference']['ci95']}。各類別校準分箱見metrics.json；尚未另擬合機率校準器。

## 剩餘得分（同6,326個可追蹤0-0打席起點）

| 預測 | RMSE（分） | MAE（分） |
| --- | ---: | ---: |
| 訓練期RE24 | {rm['RE24']['rmse']:.6f} | {rm['RE24']['mae']:.6f} |
| 球數／歷史基準E0 | {rm['count_baseline']['rmse']:.6f} | {rm['count_baseline']['mae']:.6f} |
| 知道本球後E1 | {rm['observed_pitch']['rmse']:.6f} | {rm['observed_pitch']['mae']:.6f} |

目標為該打席開始到半局結束的實際剩餘得分，不是SP的個人責任標籤。
E1相對E0的MSE差95%區間：{rs['pitch_vs_count_mse']['ci95']}。
E1相對RE24的MSE差95%區間：{rs['pitch_vs_RE24_mse']['ci95']}，跨0，不能宣稱穩定優於RE24。MAE也未優於RE24。
區間均按88場整場成組重抽2,000次，seed184，按樣本數加權，未校正選模／多重比較不確定性。

## 同一局面只換一個條件

來源案例：{row.pitch_id}，林泓育對吳俊偉，兩出局滿壘、0壞0好。固定球速{row.velocity_kph:.3f} km/h、高度z={row.plate_z_m:.3f} m及其餘輸入，只換左右位置x。

| x（m） | E0（分） | E1（分） | 投手E0−E1（分） |
| ---: | ---: | ---: | ---: |
| {a['x_m']:.4f} | {a['E0']:.6f} | {a['E1']:.6f} | {a['pitcher_runs']:+.6f} |
| {b['x_m']:.4f} | {b['E0']:.6f} | {b['E1']:.6f} | {b['pitcher_runs']:+.6f} |

這些是已訓練模型的條件式試算輸出。第二列位置來自原始紀錄，第一列為假設改位置，不是實際發生兩次投球，也不是改投位置的因果效果。此來源案例按大幅變化挑選供說明，不代表一般表現。實際終結事件不進預測特徵。

## 計算檢查與限制

12球數狀態、40組隨機機率的吸收機率檢查通過；所有結果機率和為1（最大誤差{m['checks']['max_abs_absorption_mass_error']:.2g}）。第四壞球、第三好球、兩好球界外球、全壘打邊界與投手負分方向通過。
投手／打者／野手歸因只是資訊階段差值；預測準確不等於因果分工正確。野手起始站位、個人跑速與獨立跑壘未建模。
不將逐球機率Log Loss與RE24直接相比；RE24只在同一得分目標上比較。
正式首頁尚未切換；本包是可重現研究驗證，保留既有展示版本。

## 重跑

```bash
OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 python validate_pitch_runs.py --data <資料包/data> --output results
python test_count_conversion.py
```

依賴：numpy、pandas、scikit-learn、joblib、threadpoolctl。資料來源為CPBL_2026_球位與打者擊球分布_建模資料.zip。
'''
(root/'README.md').write_text(text,encoding='utf8')
payload={'version':'v06-refit-linux','baseline':json.loads((root/'baseline.json').read_text()),'pitch':json.loads((root/'pitch.json').read_text()),'profiles':profiles,'value_tables':values}
compressed=gzip.compress(json.dumps(payload,separators=(',',':'),allow_nan=False).encode(),compresslevel=9,mtime=0);(root/'models.json.gz').write_bytes(compressed)
print(json.dumps({'model_bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),'demo':examples},ensure_ascii=False))
